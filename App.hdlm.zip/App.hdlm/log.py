from tokenize import String


String clave = "Admin1234";
String usuario = "Admin";
int x = 1;
int y = 2;
int r;

r=x+y

print r;


